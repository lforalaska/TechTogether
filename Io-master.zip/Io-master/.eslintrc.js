module.exports = {
  root: true,
  parser: '@typescript-eslint/parser',
  plugins: [
    '@typescript-eslint'
  ],
  extends: [
    'airbnb-typescript/base',
    'prettier/@typescript-eslint'
  ],
  rules: {
    "no-console": "off", // this seems arbitrary
    "max-len": ["error", {"code": 120}], // 120 max line length
    "@typescript-eslint/no-use-before-define": "off", // this is silly in the context of closures
    "class-methods-use-this": "off", // this seems arbitrary
    "import/extensions": "off", // this is broken for typescript
    "import/no-unresolved": "off", // this is broken for typescript,
    "no-plusplus": "off",  // this is a silly rule
    "import/prefer-default-export": "off" // there are lots of reasons not to default export something!
  }
}