module TimeUtils {

  export const getUnixTimestampMS = (): number => (new Date()).getTime()

}

export default TimeUtils
